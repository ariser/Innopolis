package database.service;

/**
 * Implemented queries 
 */
public enum QueryType {
	SELECT, UPDATE, DELETE, INSERT
}
