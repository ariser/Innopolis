package database.service;

/**
 * Query conditions
 */
public enum ConditionType {
	EQ, LESS, LESS_EQ, MORE, MORE_EQ, BETWEEN
}
